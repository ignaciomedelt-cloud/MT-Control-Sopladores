MT Control Sopladores — Flutter

1) flutter pub get
2) flutter run
3) flutter build apk --release
APK en: build/app/outputs/flutter-apk/app-release.apk
