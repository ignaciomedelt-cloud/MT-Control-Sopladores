# MT Control Sopladores — Build APK con 1 clic (GitHub Actions)

## Pasos
1) Sube esta carpeta al repositorio (todo tal cual).
2) Ve a la pestaña **Actions** en GitHub y ejecuta **Build Android APK**.
3) Al terminar, descarga el artefacto **app-release.apk**.

> El workflow genera la carpeta `android/` automáticamente con `flutter create . --platforms=android`.

